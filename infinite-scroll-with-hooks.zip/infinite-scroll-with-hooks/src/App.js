/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect, useRef, useState } from "react";
import { Button, Form, FormGroup, Input, Table } from "reactstrap";
import IfComponent from "./components/IfComponent";
import GithubRepository from "./repository/GithubRepository";
import loading from "./assets/loading.gif";

const App = (props) => {
  const scrollObserve = useRef();
  const [term, setTerm] = useState("");
  const [page, setPage] = useState(0);
  const [repositories, setRepositories] = useState([]);
  const [showLoading, setShowLoding] = useState(false);
  const [scrollRatio, setScrollRatio] = useState(null);

  const findRepositories = (page) => {
    setShowLoding(true);
    GithubRepository.findRepositoriesGitHub(term, page).then(({ data }) => {
      const newRepositories = [...repositories];
      newRepositories.push(...data.items);
      setRepositories(newRepositories);
      setShowLoding(false);
    });
  };

  const instersectionObserver = new IntersectionObserver((entries) => {
    const ratio = entries[0].intersectionRatio;
    setScrollRatio(ratio);
  });

  useEffect(() => {
    instersectionObserver.observe(scrollObserve.current);

    return () => {
      instersectionObserver.disconnect();
    };
  }, []);

  useEffect(() => {
    if (scrollRatio > 0 && term !== "") {
      const newPage = page + 1;
      setPage(newPage);
      findRepositories(newPage);
    }
  }, [scrollRatio]);

  return (
    <div className={"App p-4"}>
      <h1>Type a term</h1>
      <Form>
        <FormGroup>
          <Input onChange={(e) => setTerm(e.target.value)} />
        </FormGroup>
        <Button color={"primary"} onClick={() => findRepositories(page)}>
          Find
        </Button>
      </Form>
      <br />
      <br />
      <IfComponent conditional={repositories.length > 0}>
        <Table>
          <thead>
            <th>Avatar</th>
            <th>url</th>
            <th>Stars</th>
          </thead>
          <tbody>
            {repositories &&
              repositories.map((item) => (
                <tr>
                  <td>
                    <img src={item.owner.avatar_url} width={50} />
                  </td>
                  <td>
                    <a href={item.html_url} target={"_blank"}>
                      Open
                    </a>
                  </td>
                  <td>{item.stargazers_count}</td>
                </tr>
              ))}
          </tbody>
        </Table>
      </IfComponent>
      <div ref={scrollObserve}></div>
      <IfComponent conditional={showLoading}>
        <div>
          <img src={loading} width={50}></img>
        </div>
      </IfComponent>
    </div>
  );
};

export default App;
