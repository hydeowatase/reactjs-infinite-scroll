/* eslint-disable react/jsx-no-target-blank */
/* eslint-disable jsx-a11y/alt-text */
import React, { Component } from "react";
import { Button, Form, Input, Table } from "reactstrap";

import GithubRepository from "./repository/GithubRepository";

import loading from "./assets/loading.gif";

class App extends Component {
  divInfiniteScrollRef;

  state = {
    term: "",
    page: 1,
    result: [],
    showLoading: false,
  };

  _findRepositories = async () => {
    const { term, page } = this.state;
    const result = await GithubRepository.findRepositoriesGitHub(term, page);
    this.setState({ result: result.data.items });
  };

  constructor() {
    super();
    this.divInfiniteScrollRef = React.createRef();
  }

  componentDidMount() {
    const intersectionObserver = new IntersectionObserver((entries) => {
      const ratio = entries[0].intersectionRatio;
      console.log(`Ratio: ${ratio}`);

      if (ratio > 0 && this.state.term !== "") {
        this.setState({ page: this.state.page + 1, showLoading: true }, () => {
          GithubRepository.findRepositoriesGitHub(
            this.state.term,
            this.state.page
          ).then(({ data }) => {
            const resultOld = this.state.result;
            resultOld.push(...data.items);

            this.setState({
              result: resultOld,
              showLoading: false,
            });
          });
        });
      }
    });

    intersectionObserver.observe(this.divInfiniteScrollRef.current);
  }

  render() {
    const { result, showLoading } = this.state;
    return (
      <div className={"p-4"}>
        <h1>Type a term</h1>
        <Form>
          <Input onChange={(e) => this.setState({ term: e.target.value })} />
          <br />
          <Button color={"primary"} onClick={this._findRepositories}>
            Find
          </Button>
        </Form>
        <br />
        {this.state.term}
        <br />
        <Table striped>
          <thead>
            <th>Avatar</th>
            <th>url</th>
            <th>Stars</th>
          </thead>
          {result &&
            result.map((item) => (
              <tr>
                <td>
                  <img src={item.owner.avatar_url} width={50} />
                </td>
                <td>
                  <a href={item.html_url} target={"_blank"}>
                    Open
                  </a>
                </td>
                <td>{item.stargazers_count}</td>
              </tr>
            ))}
          <tbody></tbody>
        </Table>
        <div ref={this.divInfiniteScrollRef}></div>
        {showLoading && <img src={loading} width={50}></img>}
      </div>
    );
  }
}

export default App;
