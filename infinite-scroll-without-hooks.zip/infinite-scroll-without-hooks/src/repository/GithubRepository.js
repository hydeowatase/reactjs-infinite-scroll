//ff653d6d6315da4774070deda58377bc3eb9b904
import Axios from "axios";

const customAxios = Axios.create({
  headers: {
    Authorization: "token ff653d6d6315da4774070deda58377bc3eb9b904",
  },
});

export default class GithubRepository {
  static async findRepositoriesGitHub(term, page) {
    const result = await customAxios.get(
      `https://api.github.com/search/repositories?q=${term}&per_page=10&page=${page}`
    );

    return result;
  }
}
